Lab06
