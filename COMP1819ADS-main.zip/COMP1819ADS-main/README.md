# COMP1819ADS
COMP1819 Algorithms and Data Structures

Resources:
Syntax Highlight Code In Word Documents: http://www.planetb.ca/syntax-highlight-word
