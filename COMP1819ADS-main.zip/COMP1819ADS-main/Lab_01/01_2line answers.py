def minmax(sequence):
    return min(sequence), max(sequence)

print(minmax([1,2,3,5]))
print(minmax([0,1,-2]))
print(minmax([3]))